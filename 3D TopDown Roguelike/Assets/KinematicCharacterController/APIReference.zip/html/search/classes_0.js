var searchData=
[
  ['basecharactercontroller',['BaseCharacterController',['../class_kinematic_character_controller_1_1_base_character_controller.html',1,'KinematicCharacterController']]],
  ['basemovercontroller',['BaseMoverController',['../class_kinematic_character_controller_1_1_base_mover_controller.html',1,'KinematicCharacterController']]]
];
