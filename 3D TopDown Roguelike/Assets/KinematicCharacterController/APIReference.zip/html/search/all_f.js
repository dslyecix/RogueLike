var searchData=
[
  ['transform',['Transform',['../class_kinematic_character_controller_1_1_kinematic_character_motor.html#a6a65857e4b4d708daaf708a4de253973',1,'KinematicCharacterController.KinematicCharacterMotor.Transform()'],['../class_kinematic_character_controller_1_1_physics_mover.html#a1059d618d61fb89ef32297a9cc40418f',1,'KinematicCharacterController.PhysicsMover.Transform()']]],
  ['transientposition',['TransientPosition',['../class_kinematic_character_controller_1_1_kinematic_character_motor.html#a9dbefe0742fc1dcbb4a88f98be478472',1,'KinematicCharacterController.KinematicCharacterMotor.TransientPosition()'],['../class_kinematic_character_controller_1_1_physics_mover.html#a7df8dc04bcc06e49ebabe4b877435a13',1,'KinematicCharacterController.PhysicsMover.TransientPosition()']]],
  ['transientrotation',['TransientRotation',['../class_kinematic_character_controller_1_1_kinematic_character_motor.html#aa59e39e5cdd226c64c6068d3df6f1d60',1,'KinematicCharacterController.KinematicCharacterMotor.TransientRotation()'],['../class_kinematic_character_controller_1_1_physics_mover.html#a95f6198496dbfa103be5e56b01e4094b',1,'KinematicCharacterController.PhysicsMover.TransientRotation()']]]
];
